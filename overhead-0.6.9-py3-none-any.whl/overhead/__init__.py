
from setuptools import setuptools, setup
# setup(1)

#
setup(name             = "overhead",
      py_modules       = ["overhead.aioh", "overhead.cryptooh", "overhead.opengloh"])
