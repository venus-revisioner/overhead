# coding=utf-8
import os

import numpy as np
import torch
from torch import Tensor
from torchvision.utils import make_grid


def save_models(generator, discriminator, epochs):
	torch.save(generator.state_dict(), "saved_models/generator_%d.pth" % epochs)
	torch.save(discriminator.state_dict(), "saved_models/discriminator_%d.pth" % epochs)


def load_models(generator, discriminator, epochs):
	generator.load_state_dict(torch.load("saved_models/generator_%d.pth" % epochs))
	discriminator.load_state_dict(torch.load("saved_models/discriminator_%d.pth" % epochs))
	return epochs


def tensor_to_numpy(tensor):
	grid = make_grid(tensor)
	# Add 0.5 after unnormalizing to [0, 255] to round to nearest integer
	ndarr = grid.mul(0.5).add_(0.5).clamp_(0., 1.).permute(1, 2, 0).to("cpu", torch.float32).numpy()
	return np.rot90(ndarr.astype(np.float32), -1)


def find_latest_epoch(gen, disc, ep=0):
	for file in os.listdir("saved_models"):
		if file.endswith(".pth"):
			ep = max(ep, int(file.split("_")[1].split(".")[0]))
	if ep > 0:
		ep = load_models(gen, disc, ep)
	return ep
