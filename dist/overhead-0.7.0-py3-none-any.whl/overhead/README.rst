overhead-0.7.0
Title: overhead
Version: 0.7.0
Date: 2022-10-03

Description: A simple, lightweight, and fast overhead for me.
My _overhead_ tools of mixed-bag-distribution, self-organized, self-build.
Used in many many projects as helper packages, functions and Classes.

