# Importing all the modules in the __all__ list.
# import os
# import importlib
#
# overpackages = os.listdir(".")
# __all__ = [i for i in overpackages if "__" not in i]
# print(__all__)
# [importlib.import_module(f'{i.replace(".py", "")}') for i in __all__]
