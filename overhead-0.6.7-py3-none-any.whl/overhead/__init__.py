
# from setuptools import setup
#
#
# setup(name             = "overhead",
#       version          = "0.6.6",
#       author           = "venus-revisioner",
#       author_email     = "johan.uhd@gmail.com",
#       url              = "https://github.com/venus-revisioner/overhead-0.6.6.git",
#       description      = "'Overhead' tools of mixed-bag-distribution, self-organized.",
#       readme 	       = "README.md",
#       license   	   =  "LICENSE",
#       long_description = "'TL;DR'",
#       py_modules       = ["overhead.aioh", "overhead.cryptooh", "overhead.opengloh"])
